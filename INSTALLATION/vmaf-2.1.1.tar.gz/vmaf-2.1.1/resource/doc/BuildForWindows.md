# Prepare  [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/68i57b8ssasttngg?svg=true)](https://ci.appveyor.com/project/li-zhi/vmaf)
  - Visual Studio 2015 on Windows
  
# Steps
  - 1.open [vmaf.sln](../../vmaf.sln) in Visual Studio 2015 
  - 2.Select Build => Batch Build from menu
  - 3.Select the Solution Config as your want or Select All, then Build.
  - 4.After Build, you will find all the build result in $(SolutionDir)/x64/$(Configuration), and there is examples.bat that you can run.
