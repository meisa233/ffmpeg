function run_strred(ref_filename, dis_filename, width, height)

path(path,'./strred');
path(path,'./matlabPyrTools');

calcStrredScore(ref_filename, dis_filename, height, width);

% dmos_score = rred2dmos(strred_score)

end
























